package com.codesparts.finalapplication;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    public  class  DownloadTask extends AsyncTask<String,Void,String>
    {
        @Override
        protected  String doInBackground(String... params )
        {
            String result = "";
            URL url  ;
            HttpURLConnection urlConnection = null ;
            try {

                url = new URL(params[0]) ;
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();

                InputStreamReader reader = new InputStreamReader(in);

                int data = reader.read();
                while(data!=-1)
                {
                    char current  = (char )data ;
                    result += current ;
                    data=reader.read();

                }


            }
            catch (Exception e )
            {
                Log.i("exception","caught");
                e.printStackTrace();
            }
            return  result ;

        }
    }
    public void hideElements()
    {
        TextView userId = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);
        userId.setVisibility(View.INVISIBLE);
        password.setVisibility(View.INVISIBLE);
        TextView button = (TextView) findViewById(R.id.loginButton);
        button.setVisibility(View.INVISIBLE);
        TextView edit = ( TextView ) findViewById( R.id.editText3);
        edit.setVisibility(View.INVISIBLE);

    }
    public void LoginUser(View view)
    {
        EditText userIdVar = (EditText) findViewById(R.id.username);
        EditText userPasVar = (EditText ) findViewById(R.id.password);
        String  userName = userIdVar.getText().toString() ;
        String  userPassword = userPasVar.getText().toString();
        String verifyUrl = "http://www.aryansuraj.xyz/test/functions.php?function=getData&userid="+userName+"&password="+userPassword;
        DownloadTask task =  new DownloadTask() ;
        String result  =  null ;

        try {
            result = task.execute(verifyUrl).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        Log.i("result",result);
        if (result.equals("error"))
        {
            Toast.makeText(getApplicationContext(),"Wrong user name or password try again ",Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            hideElements();
            //String dataURL  = "http://www.aryansuraj.xyz/test/functions.php?function=getData&userid="+userName+"&password="+userPassword;

            Log.i("data", result);
            String[]  tokens = result.split(" ");

            ListView myView = (ListView ) findViewById(R.id.MyList);
            ArrayList<String > myDat = new ArrayList<String>();
            tokens[0]="User ID:" + tokens[0];
            tokens[1]="Billing ID:"+tokens[1] ;
            tokens[2]="Appartment ID:"+tokens[2] ;
            tokens[3]="Todays useage in liters :"+tokens[3] ;
            tokens[4]="This months Useage in liter: "+tokens[4] ;
            tokens[5]="This year's useage :"+tokens[5] ;
            tokens[6]="pH of the water :"+tokens[6] ;
            tokens[7]="Price of water per liter :"+tokens[7] ;

            for (String token : tokens)
            {
                myDat.add(token);
            }

            ArrayAdapter<String> arrayAdapter  = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,myDat);
            myView.setAdapter(arrayAdapter);

           myView.setVisibility(View.VISIBLE);
        }

        return;


    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
